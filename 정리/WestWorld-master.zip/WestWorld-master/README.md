자세한 설명은 아래 링크 참조

-> http://aidev.co.kr/game/1178
